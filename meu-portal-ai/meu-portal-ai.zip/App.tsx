
import React, { useState, useEffect } from 'react';
import { Post, ViewMode, UserState } from './types';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Editor from './components/Editor';
import Reader from './components/Reader';
import { fetchBreakingNews, generateViralFeed } from './services/geminiService';

const App: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [currentView, setCurrentView] = useState<ViewMode>(ViewMode.Dashboard);
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [isGeneratingViral, setIsGeneratingViral] = useState(false);
  
  const [userState, setUserState] = useState<UserState>(() => {
    const saved = localStorage.getItem('user_monetization');
    return saved ? JSON.parse(saved) : { 
      balance: 15.50, 
      totalCommissions: 0, 
      clicksToday: 0, 
      lastDailyBonus: 0,
      robotActive: true 
    };
  });

  useEffect(() => {
    localStorage.setItem('user_monetization', JSON.stringify(userState));
  }, [userState]);

  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        const news = await fetchBreakingNews();
        setPosts(news);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    loadInitialData();
  }, []);

  const handleGenerateViral = async () => {
    setIsGeneratingViral(true);
    try {
      const viralPosts = await generateViralFeed();
      setPosts(prev => [...viralPosts, ...prev]);
      alert("🚀 10 NOTÍCIAS VIRAIS INJETADAS COM SUCESSO!");
    } catch (error) {
      alert("Erro ao injetar pautas virais.");
    } finally {
      setIsGeneratingViral(false);
    }
  };

  const handleReadPost = (id: string) => {
    setSelectedPostId(id);
    setCurrentView(ViewMode.Reader);
    setUserState(prev => ({ ...prev, balance: prev.balance + 0.10 }));
  };

  const handleShopeeClick = (postId: string) => {
    setUserState(prev => ({
      ...prev,
      totalCommissions: prev.totalCommissions + 2.50,
      clicksToday: prev.clicksToday + 1,
      balance: prev.balance + 1.25
    }));
    
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, clicks: (p.clicks || 0) + 1 } : p));
  };

  const currentPost = selectedPostId ? posts.find(p => p.id === selectedPostId) : null;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Header 
        onNavigate={(view) => setCurrentView(view)} 
        currentView={currentView}
        onNewPost={() => setCurrentView(ViewMode.Editor)}
        balance={userState.balance}
      />
      
      <div className="marquee-container">
        <div className="marquee-content">
          🚨 ROBÔ DE MONETIZAÇÃO ATIVO: {userState.clicksToday} CLIQUES HOJE • COMISSÕES ESTIMADAS: R$ {userState.totalCommissions.toFixed(2)} • 🚨
        </div>
      </div>

      <main className="flex-grow container mx-auto px-4 py-8 max-w-7xl">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-32">
            <div className="w-16 h-16 border-4 border-red-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="mt-4 font-black text-red-600 uppercase italic">Iniciando Motores de Monetização...</p>
          </div>
        ) : (
          <>
            {currentView === ViewMode.Dashboard && (
              <Dashboard 
                posts={posts} 
                userState={userState}
                onRead={handleReadPost}
                onToggleRobot={() => setUserState(prev => ({ ...prev, robotActive: !prev.robotActive }))}
                onGenerateViral={handleGenerateViral}
                isGeneratingViral={isGeneratingViral}
              />
            )}
            
            {currentView === ViewMode.Editor && (
              <Editor 
                onSave={(p) => { setPosts([p, ...posts]); setCurrentView(ViewMode.Dashboard); }}
                onCancel={() => setCurrentView(ViewMode.Dashboard)}
              />
            )}

            {currentView === ViewMode.Reader && currentPost && (
              <Reader 
                post={currentPost} 
                onBack={() => setCurrentView(ViewMode.Dashboard)}
                onShopeeClick={() => handleShopeeClick(currentPost.id)}
              />
            )}
          </>
        )}
      </main>

      <footer className="bg-slate-900 text-white p-10 text-center text-[10px] font-black uppercase tracking-widest">
        BRASIL URGENTE AI - SISTEMA DE MONETIZAÇÃO AUTOMÁTICA ATIVO
      </footer>
    </div>
  );
};

export default App;
