
import { GoogleGenAI, Type } from "@google/genai";
import { Post } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const fetchNewsByCategory = async (category: string = 'Brasil'): Promise<Post[]> => {
  const date = new Date().toLocaleDateString('pt-BR');
  const query = category === 'Tudo' ? 'últimas notícias urgentes Brasil agora' : `últimas notícias sobre ${category} Brasil hoje`;
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Busque 15 notícias reais de ${query} hoje (${date}). Retorne JSON com title, content, excerpt, category, url.`,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            content: { type: Type.STRING },
            excerpt: { type: Type.STRING },
            category: { type: Type.STRING },
            url: { type: Type.STRING }
          },
          required: ["title", "content", "excerpt", "category", "url"]
        }
      }
    }
  });

  try {
    const rawData = JSON.parse(response.text || "[]");
    return rawData.map((item: any, index: number) => ({
      ...item,
      id: `news-${Date.now()}-${index}`,
      status: 'published',
      createdAt: Date.now() - (index * 600000),
      author: "Redação IA",
      image: `https://images.unsplash.com/photo-${1500000000000 + (index * 123456)}?auto=format&fit=crop&w=800&q=80`,
      shopeeUrl: '',
      shopeeProductImage: '',
      clicks: 0
    }));
  } catch (e) {
    return [];
  }
};

export const fetchBreakingNews = async (): Promise<Post[]> => {
  return fetchNewsByCategory('Tudo');
};

// NOVO: Gerador de 10 Pautas Virais para Monetização Instantânea
export const generateViralFeed = async (): Promise<Post[]> => {
  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: "Gere 10 notícias 'clickbait' virais sobre produtos que as pessoas amam (tecnologia, casa, beleza). Cada notícia deve ter um título forte, conteúdo envolvente, uma categoria, e sugestão de produto Shopee (nome e imagem placeholder). Retorne apenas JSON.",
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            content: { type: Type.STRING },
            excerpt: { type: Type.STRING },
            category: { type: Type.STRING },
            shopeeProductName: { type: Type.STRING },
            shopeeProductImage: { type: Type.STRING }
          },
          required: ["title", "content", "excerpt", "category"]
        }
      }
    }
  });

  try {
    const rawData = JSON.parse(response.text || "[]");
    return rawData.map((item: any, index: number) => ({
      ...item,
      id: `viral-${Date.now()}-${index}`,
      status: 'published',
      createdAt: Date.now(),
      author: "Robô Viral IA",
      image: `https://loremflickr.com/1200/800/${item.category.toLowerCase()}?lock=${index}`,
      shopeeUrl: `https://shopee.com.br/search?keyword=${encodeURIComponent(item.shopeeProductName || 'ofertas')}`,
      clicks: 0
    }));
  } catch (e) {
    return [];
  }
};

export const suggestMonetization = async (content: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Com base nesta notícia: "${content.substring(0, 500)}", sugira um tipo de produto da Shopee que as pessoas comprariam após ler isso. Retorne apenas o nome do produto e uma manchete de venda ultra agressiva.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          productType: { type: Type.STRING },
          viralHeadline: { type: Type.STRING }
        }
      }
    }
  });
  return JSON.parse(response.text || "{}");
};
