
import React, { useState } from 'react';
import { Post, UserState } from '../types';

interface DashboardProps {
  posts: Post[];
  userState: UserState;
  onRead: (id: string) => void;
  onToggleRobot: () => void;
  onGenerateViral: () => void;
  isGeneratingViral: boolean;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  posts, 
  userState, 
  onRead, 
  onToggleRobot, 
  onGenerateViral,
  isGeneratingViral 
}) => {
  const [showGuide, setShowGuide] = useState(false);

  return (
    <div className="space-y-8">
      {/* PAINEL DO ROBÔ IA */}
      <div className="bg-slate-900 rounded-[40px] p-8 text-white shadow-2xl relative overflow-hidden border-4 border-red-600">
        <div className="absolute top-0 right-0 w-64 h-64 bg-red-600/10 rounded-full -mr-20 -mt-20 blur-3xl"></div>
        
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-4 gap-8 items-center">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-4 mb-4">
              <div className={`w-4 h-4 rounded-full animate-pulse ${userState.robotActive ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <h2 className="text-2xl font-black italic uppercase tracking-tighter">Robô de Monetização IA</h2>
            </div>
            <p className="text-slate-400 text-sm font-bold leading-relaxed">
              O robô está injetando pautas de alta conversão. Use o botão abaixo para forçar a criação de notícias virais agora!
            </p>
            <div className="flex flex-wrap gap-4 mt-6">
              <button 
                onClick={onToggleRobot}
                className={`px-6 py-3 rounded-full font-black text-[10px] uppercase tracking-widest transition-all ${
                  userState.robotActive ? 'bg-slate-700 hover:bg-slate-600' : 'bg-green-600 hover:bg-green-700'
                }`}
              >
                {userState.robotActive ? 'Pausar Robô' : 'Retomar Robô'}
              </button>
              
              <button 
                onClick={onGenerateViral}
                disabled={isGeneratingViral}
                className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-full font-black text-[10px] uppercase tracking-widest transition-all shadow-xl animate-bounce hover:animate-none disabled:opacity-50 disabled:animate-none"
              >
                {isGeneratingViral ? 'Injetando...' : '🚀 INJETAR 10 PAUTAS VIRAIS'}
              </button>
              
              <button 
                onClick={() => setShowGuide(!showGuide)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-full font-black text-[10px] uppercase tracking-widest transition-all"
              >
                <i className="fas fa-rocket mr-2"></i> Como Lançar no Vercel
              </button>
            </div>
          </div>

          <div className="bg-slate-800/50 p-6 rounded-3xl border border-slate-700 text-center">
            <div className="text-[10px] font-black text-slate-500 uppercase mb-2">Cliques Reais (Hoje)</div>
            <div className="text-4xl font-black text-red-500">{userState.clicksToday}</div>
            <div className="text-[10px] font-black text-green-500 mt-2">+12% vs Ontem</div>
          </div>

          <div className="bg-slate-800/50 p-6 rounded-3xl border border-slate-700 text-center">
            <div className="text-[10px] font-black text-slate-500 uppercase mb-2">Comissões Estimadas</div>
            <div className="text-4xl font-black text-green-500">R$ {userState.totalCommissions.toFixed(2)}</div>
            <div className="text-[10px] font-black text-slate-400 mt-2">Pagamento em 24h</div>
          </div>
        </div>

        {/* GUIA DE LANÇAMENTO EXPANSÍVEL */}
        {showGuide && (
          <div className="mt-8 p-6 bg-slate-800 rounded-3xl border border-blue-500/30 animate-in fade-in slide-in-from-top-4 duration-500">
            <h3 className="text-blue-400 font-black uppercase text-sm mb-4 tracking-widest">Guia de Lançamento Gratuito (Vercel)</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-[11px] font-medium leading-relaxed">
              <div className="space-y-2">
                <div className="text-blue-400 font-black">PASSO 1</div>
                <p>Crie uma conta no <b>GitHub.com</b> e suba todos os arquivos deste projeto em um novo repositório.</p>
              </div>
              <div className="space-y-2">
                <div className="text-blue-400 font-black">PASSO 2</div>
                <p>No <b>Vercel.com</b>, conecte seu GitHub e importe o projeto. É 100% gratuito para sites pequenos.</p>
              </div>
              <div className="space-y-2">
                <div className="text-blue-400 font-black">PASSO 3</div>
                <p>Nas "Environment Variables" do Vercel, adicione a chave <b>API_KEY</b> com o valor da sua chave Gemini.</p>
              </div>
            </div>
            <p className="mt-4 text-[10px] text-slate-500 italic text-center uppercase font-black">Pronto! Seu blog estará online com link profissional em segundos.</p>
          </div>
        )}
      </div>

      {/* FEED DE NOTÍCIAS */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {posts.map((post, idx) => (
          <div 
            key={post.id} 
            className={`bg-white rounded-[32px] overflow-hidden border-2 transition-all cursor-pointer group hover:shadow-2xl ${
              idx === 0 ? 'md:col-span-2 lg:col-span-2 border-red-100 shadow-xl' : 'border-slate-100'
            }`}
            onClick={() => onRead(post.id)}
          >
            <div className={`relative ${idx === 0 ? 'h-96' : 'h-52'}`}>
              <img src={post.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
              <div className="absolute bottom-4 left-6 flex gap-2">
                <span className="bg-red-600 text-white px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter">{post.category}</span>
                {post.id.startsWith('viral') && (
                  <span className="bg-orange-500 text-white px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter italic animate-pulse">ALTA CONVERSÃO</span>
                )}
              </div>
              {post.clicks && post.clicks > 0 && (
                <div className="absolute top-4 right-4 bg-orange-600 text-white px-3 py-1 rounded-full text-[10px] font-black shadow-xl">
                  🔥 {post.clicks} CLIQUES
                </div>
              )}
            </div>
            <div className="p-8">
              <h3 className={`${idx === 0 ? 'text-4xl' : 'text-xl'} font-black text-slate-900 leading-tight mb-4 group-hover:text-red-600 transition-colors uppercase italic tracking-tighter`}>
                {post.title}
              </h3>
              <p className="text-slate-500 text-sm line-clamp-2 font-medium mb-6">{post.excerpt}</p>
              <div className="flex items-center justify-between pt-6 border-t border-slate-50">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-[10px] text-white font-black italic">BU</div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{post.author}</span>
                </div>
                <span className="text-red-600 font-black text-xs uppercase flex items-center gap-2">
                  Ver Conteúdo <i className="fas fa-arrow-right"></i>
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
