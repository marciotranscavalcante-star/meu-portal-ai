
import React, { useState } from 'react';
// Fix: Removed AIResponse as it is not exported from types.ts and not used in this file.
import { Post } from '../types';
// Fix: Removed generateBlogPost and improveContent as they are not exported from geminiService.ts and not used in this file.

interface EditorProps {
  post?: Post;
  onSave: (post: Post) => void;
  onCancel: () => void;
}

const Editor: React.FC<EditorProps> = ({ post, onSave, onCancel }) => {
  const [title, setTitle] = useState(post?.title || '');
  const [content, setContent] = useState(post?.content || '');
  const [excerpt, setExcerpt] = useState(post?.excerpt || '');
  const [category, setCategory] = useState(post?.category || 'Política');
  const [shopeeUrl, setShopeeUrl] = useState(post?.shopeeUrl || '');
  const [shopeeProductImage, setShopeeProductImage] = useState(post?.shopeeProductImage || '');
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');

  const handleSave = () => {
    if (!title.trim() || !content.trim()) {
      alert("Preencha título e conteúdo.");
      return;
    }
    const newPost: Post = {
      id: post?.id || Date.now().toString(),
      title,
      content,
      excerpt: excerpt || content.substring(0, 150).replace(/<[^>]*>/g, '') + '...',
      category,
      status: 'published',
      createdAt: post?.createdAt || Date.now(),
      author: 'Redação Brasil Urgente',
      image: post?.image || `https://picsum.photos/seed/${Date.now()}/800/500`,
      shopeeUrl,
      shopeeProductImage
    };
    onSave(newPost);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-20">
      <div className="lg:col-span-2 space-y-6">
        {/* Notícia Principal */}
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xl">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="MANCHETE DA NOTÍCIA..."
            className="w-full text-4xl font-black text-slate-900 placeholder-slate-200 border-none focus:ring-0 mb-6 uppercase italic"
          />
          
          <div className="flex flex-wrap gap-2 mb-6">
            <select 
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="bg-red-50 border-none text-[10px] font-black text-red-600 rounded-xl px-4 py-2 uppercase tracking-widest focus:ring-2 focus:ring-red-200"
            >
              <option>Política</option>
              <option>Economia</option>
              <option>Esportes</option>
              <option>Tecnologia</option>
              <option>Saúde</option>
              <option>Mundo</option>
            </select>
            
            <button className="flex items-center gap-2 px-4 py-2 text-[10px] font-black text-violet-600 bg-violet-50 rounded-xl hover:bg-violet-100 transition-all uppercase">
              <i className="fas fa-magic"></i> SEO IA
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-[10px] font-black text-blue-600 bg-blue-50 rounded-xl hover:bg-blue-100 transition-all uppercase">
              <i className="fas fa-hashtag"></i> Gerar Tags
            </button>
          </div>
          
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Relate o fato..."
            className="w-full min-h-[400px] text-slate-800 leading-relaxed border-none focus:ring-0 resize-none font-serif text-xl"
          />
        </div>

        {/* Módulo Shopee Avançado */}
        <div className="bg-gradient-to-br from-orange-50 to-white p-8 rounded-3xl border-2 border-orange-200 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-black text-orange-800 flex items-center gap-3 uppercase text-sm tracking-widest">
              <i className="fas fa-shopping-bag text-2xl"></i>
              Monetização Shopee
            </h3>
            <span className="bg-orange-600 text-white text-[9px] font-black px-3 py-1 rounded-full uppercase">Comissão Ativa</span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <label className="text-[10px] font-black text-orange-900 uppercase tracking-widest">Link do Produto</label>
              <input
                type="url"
                value={shopeeUrl}
                onChange={(e) => setShopeeUrl(e.target.value)}
                placeholder="Link de Afiliado Shopee..."
                className="w-full bg-white rounded-2xl p-4 text-sm border border-orange-200 focus:ring-2 focus:ring-orange-500 outline-none"
              />
              <button className="w-full bg-orange-100 text-orange-700 py-3 rounded-xl font-black text-[10px] uppercase hover:bg-orange-200 transition-all">
                <i className="fas fa-link mr-2"></i> Validar Link
              </button>
            </div>

            <div className="space-y-4">
              <label className="text-[10px] font-black text-orange-900 uppercase tracking-widest">Foto do Produto (URL)</label>
              <input
                type="url"
                value={shopeeProductImage}
                onChange={(e) => setShopeeProductImage(e.target.value)}
                placeholder="Link da imagem da Shopee..."
                className="w-full bg-white rounded-2xl p-4 text-sm border border-orange-200 focus:ring-2 focus:ring-orange-500 outline-none"
              />
              <button className="w-full bg-orange-600 text-white py-3 rounded-xl font-black text-[10px] uppercase hover:bg-orange-700 transition-all shadow-lg">
                <i className="fas fa-camera mr-2"></i> Adicionar Foto
              </button>
            </div>
          </div>
          
          {shopeeProductImage && (
            <div className="mt-6 flex items-center gap-4 bg-white p-3 rounded-2xl border border-orange-100">
              <img src={shopeeProductImage} className="w-16 h-16 object-cover rounded-xl border border-orange-50" alt="Preview" />
              <div>
                <p className="text-xs font-black text-orange-900 uppercase">Preview da Foto</p>
                <p className="text-[10px] text-slate-400">A imagem aparecerá no card de oferta dentro da notícia.</p>
              </div>
              <button onClick={() => setShopeeProductImage('')} className="ml-auto text-red-500 p-2"><i className="fas fa-trash"></i></button>
            </div>
          )}
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-slate-900 p-8 rounded-3xl text-white shadow-2xl">
          <h3 className="font-black text-xl mb-6 italic text-red-500">
            IA REPORTER PRO
          </h3>
          <textarea
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            placeholder="Qual é a pauta de hoje?"
            className="w-full h-32 bg-slate-800 rounded-2xl p-4 text-sm border-none focus:ring-2 focus:ring-red-600 mb-4"
          />
          <div className="grid grid-cols-2 gap-2">
            <button className="bg-slate-800 hover:bg-slate-700 p-3 rounded-xl text-[9px] font-black uppercase">Clickbait</button>
            <button className="bg-slate-800 hover:bg-slate-700 p-3 rounded-xl text-[9px] font-black uppercase">Formal</button>
          </div>
          <button 
            onClick={() => setIsGenerating(true)}
            className="w-full bg-red-600 hover:bg-red-700 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest mt-4 shadow-xl"
          >
            GERAR NOTÍCIA COMPLETA
          </button>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xl space-y-3">
          <button 
            onClick={handleSave}
            className="w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg"
          >
            Publicar no Portal
          </button>
          <button 
            onClick={onCancel}
            className="w-full bg-slate-50 text-slate-400 py-4 rounded-2xl font-black text-xs uppercase tracking-widest"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
};

export default Editor;
