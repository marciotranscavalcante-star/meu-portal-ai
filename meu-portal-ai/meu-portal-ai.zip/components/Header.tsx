
import React, { useState, useEffect } from 'react';
import { ViewMode } from '../types';

interface HeaderProps {
  onNavigate: (view: ViewMode) => void;
  currentView: ViewMode;
  onNewPost: () => void;
  balance?: number;
}

const Header: React.FC<HeaderProps> = ({ onNavigate, currentView, onNewPost, balance = 0 }) => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="bg-white border-b-8 border-red-600 sticky top-0 z-[100] shadow-2xl">
      <div className="container mx-auto px-4 h-24 flex items-center justify-between">
        <div 
          className="flex items-center gap-4 cursor-pointer group"
          onClick={() => onNavigate(ViewMode.Dashboard)}
        >
          <div className="bg-red-600 text-white px-4 py-2 rounded-lg transform -skew-x-12 shadow-xl group-hover:scale-105 transition-transform">
            <span className="font-news text-3xl tracking-tighter">BRASIL</span>
          </div>
          <div className="hidden sm:block">
            <h1 className="text-3xl font-black tracking-tighter text-slate-900 leading-none">
              URGENTE<span className="text-red-600">.AI</span>
            </h1>
            <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">
              O Portal da Verdade Instantânea
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6">
          {/* Relógio em Tempo Real */}
          <div className="hidden lg:flex flex-col items-end border-r border-slate-200 pr-6 mr-2">
            <div className="text-xl font-black text-slate-900 tabular-nums">
              {time.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </div>
            <div className="text-[9px] font-black text-red-600 uppercase tracking-widest">
              Brasília, {time.toLocaleDateString('pt-BR', { weekday: 'long' }).split('-')[0]}
            </div>
          </div>

          {/* Wallet Widget */}
          <div className="flex flex-col items-end">
            <div className="bg-slate-950 text-white px-5 py-2.5 rounded-2xl flex items-center gap-3 shadow-2xl hover:bg-red-600 transition-colors cursor-pointer group">
              <div className="flex flex-col items-end">
                <span className="text-[8px] font-black text-slate-400 group-hover:text-white uppercase">Seu Saldo</span>
                <span className="text-sm font-black text-green-400">R$ {balance.toFixed(2)}</span>
              </div>
              <i className="fas fa-wallet text-xl"></i>
            </div>
          </div>

          <button 
            onClick={onNewPost}
            className="bg-red-600 hover:bg-slate-900 text-white w-14 h-14 sm:w-auto sm:px-6 rounded-2xl font-black text-xs transition-all flex items-center justify-center gap-3 shadow-xl hover:shadow-red-200"
          >
            <i className="fas fa-plus-circle text-xl"></i>
            <span className="hidden sm:inline uppercase tracking-widest">Novo Post</span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
