
import React from 'react';
import { Post } from '../types';

interface ReaderProps {
  post: Post;
  onBack: () => void;
  onShopeeClick: () => void;
}

const Reader: React.FC<ReaderProps> = ({ post, onBack, onShopeeClick }) => {
  return (
    <div className="max-w-4xl mx-auto pb-20">
      <button 
        onClick={onBack}
        className="mb-8 text-slate-400 hover:text-red-600 flex items-center gap-2 font-black uppercase text-xs tracking-widest transition-all"
      >
        <i className="fas fa-long-arrow-alt-left text-xl"></i> Voltar ao Fluxo
      </button>

      <article className="bg-white rounded-[40px] shadow-2xl overflow-hidden border border-slate-100">
        <div className="h-[450px] relative">
          <img src={post.image} className="w-full h-full object-cover" alt="" />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex items-end p-12">
            <h1 className="text-4xl md:text-5xl font-black text-white leading-none uppercase italic tracking-tighter">
              {post.title}
            </h1>
          </div>
        </div>

        <div className="p-12">
          <div className="flex items-center gap-4 mb-10 pb-8 border-b border-slate-50">
            <div className="w-14 h-14 rounded-full bg-red-600 flex items-center justify-center text-white text-xl font-black italic">BU</div>
            <div>
              <div className="font-black text-slate-900 uppercase text-sm tracking-tight">{post.author}</div>
              <div className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Postado há {Math.floor(Math.random() * 59)} minutos</div>
            </div>
          </div>

          <div 
            className="prose prose-slate prose-lg max-w-none text-slate-700 leading-relaxed font-serif mb-16"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />

          {/* ÁREA DE MONETIZAÇÃO - ONDE O DINHEIRO ACONTECE */}
          <div className="bg-gradient-to-br from-orange-500 to-red-600 p-1 rounded-[45px] shadow-2xl shadow-orange-200">
            <div className="bg-white p-10 rounded-[42px] flex flex-col md:flex-row items-center gap-10">
              <div className="w-56 h-56 bg-slate-50 rounded-3xl p-4 flex items-center justify-center relative flex-shrink-0">
                <img 
                  src={post.shopeeProductImage || "https://img.icons8.com/clouds/256/shopee.png"} 
                  className="max-w-full max-h-full object-contain" 
                  alt="Produto" 
                />
                <div className="absolute -top-4 -right-4 bg-red-600 text-white w-12 h-12 rounded-full flex items-center justify-center font-black text-xs shadow-xl animate-bounce">
                  -70%
                </div>
              </div>
              
              <div className="flex-grow text-center md:text-left">
                <img src="https://logodownload.org/wp-content/uploads/2021/03/shopee-logo-0.png" className="h-6 mx-auto md:mx-0 mb-4" alt="" />
                <h3 className="text-3xl font-black text-slate-900 mb-2 leading-tight uppercase italic tracking-tighter">Oferta Relâmpago IA</h3>
                <p className="text-slate-500 font-bold mb-8 uppercase text-[10px] tracking-widest">Baseado no seu interesse nesta notícia</p>
                
                <a 
                  href={post.shopeeUrl || "#"} 
                  target="_blank" 
                  onClick={onShopeeClick}
                  className="inline-block w-full md:w-auto bg-[#ee4d2d] hover:bg-slate-900 text-white px-12 py-5 rounded-2xl font-black text-xl shadow-2xl transition-all hover:scale-105 active:scale-95 text-center"
                >
                  VER NA SHOPEE <i className="fas fa-shopping-cart ml-3"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </article>

      {/* FEEDBACK DE GANHOS AO CLICAR */}
      <div className="mt-12 text-center">
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">Anúncio Patrocinado pela Rede Brasil Urgente AI</p>
      </div>
    </div>
  );
};

export default Reader;
