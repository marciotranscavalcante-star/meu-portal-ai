
export interface Post {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  category: string;
  status: 'draft' | 'published';
  createdAt: number;
  author: string;
  url?: string;
  image?: string;
  shopeeUrl?: string;
  shopeeProductImage?: string;
  clicks?: number; // Contador de cliques reais
}

export interface UserState {
  balance: number;
  totalCommissions: number;
  clicksToday: number;
  lastDailyBonus: number;
  robotActive: boolean;
}

export enum ViewMode {
  Dashboard = 'dashboard',
  Editor = 'editor',
  Reader = 'reader'
}
